var first = "FullStack+change";
document.write("FullStack <br>");
document.write(first);
document.write("<h1>도큐먼트 객체</h1>");